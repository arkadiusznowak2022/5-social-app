import React from 'react';
import './ErrorPage.css';

function ErrorPage() {
  return <div>ErrorPage</div>;
}

export default ErrorPage;
