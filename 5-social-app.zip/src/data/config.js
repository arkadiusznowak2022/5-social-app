export const WRONG_PASS_MSG =
  'The password should contain at least 6 characters and: one uppercase character, one digid, one special character (!, @, #, $, %)';
export const DIFF_PASS_MSG = 'Different passwords!';
export const SHOW_MSG_TIME = 2000;

export const LOGIN_DEMO_MSG = 'login: adam, pass: 1234';
export const TIME_TO_LOGIN_POPUP = 10000;
export const TIME_TO_LOGOUT = 3_000_000;
